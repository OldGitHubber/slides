// This is a line comment

/* This is a 
   block comment
   over multiple lines
*/

let x=3
let y=2.5
y=x+y

let firstName='Jimmy' // camel case
let lastName='Smith'
let wholeName=firstName + ' ' +lastName
console.log('Full name:' + firstName + ' ' + lastName + ' and y=', y)

console.log(`Full name: ${firstName} ${lastName} and y=${y}`)

// Full name: Jimmy Smith and y=5.5