
for (let i=20; i >=0; i--) {
  let rand=Math.floor(Math.random()*50)+1;
  console.log(`Random number ${i} is ${rand}`);
}