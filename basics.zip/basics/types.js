// Single line comment

/* Block comment
   over several
   lines
*/


let x=3;
let y=2.5;

let z=x+y;

console.log('x=%d y=%d z=%d',x,y,z)          // C style printf format
console.log('x=' + x + ' y=' + y + ' z=' + z) // Older concatenation method
console.log(`x=${x} y=${y} z=${z}`)          // New neat addition using backtick

let firstName='Jimmy'
let fullName=firstName+' Riddle'

console.log(fullName)

// Various operators
x++
y+=5

console.log(`x=${x} y=${y}`)

console.log(`A num divided by a string is not a number: ${x/firstName}`)

let w
console.log(`w is: ${w}`)

console.log(`Type of x is ${typeof x} and type of firstName is ${typeof firstName}`)