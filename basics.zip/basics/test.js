let x=3
let y=2.5
y=x+y

let firstName='Jimmy' // camel case
let lastName='Smith'
console.log('Full name:' + firstName + ' ' + lastName + ' and y=', y)

console.log(`Full name: ${firstName} ${lastName} and y=${y}`)